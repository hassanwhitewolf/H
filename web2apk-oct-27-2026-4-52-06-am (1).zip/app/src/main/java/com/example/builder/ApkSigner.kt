package com.example.builder

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.X509Certificate
import java.util.Arrays
import java.util.Base64
import java.util.LinkedHashMap
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ApkSigner {

    fun signApk(
        context: Context,
        inputApkBytes: ByteArray,
        outputFile: File
    ) {
        val (privateKey, cert) = loadKeystore(context)

        // Read all entries except META-INF
        val files = LinkedHashMap<String, ByteArray>()
        val zis = ZipInputStream(inputApkBytes.inputStream())
        var entry: ZipEntry? = zis.nextEntry
        while (entry != null) {
            if (!entry.name.startsWith("META-INF/")) {
                val baos = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var n: Int
                while (zis.read(buf).also { n = it } != -1) {
                    baos.write(buf, 0, n)
                }
                files[entry.name] = baos.toByteArray()
            }
            entry = zis.nextEntry
        }
        zis.close()

        val sha256 = MessageDigest.getInstance("SHA-256")
        val sha1 = MessageDigest.getInstance("SHA-1")

        // 1. Generate MANIFEST.MF with both SHA-256 and SHA-1 for universal compatibility
        val manifestSb = StringBuilder()
        manifestSb.append("Manifest-Version: 1.0\r\nCreated-By: 1.0 (Web2APK)\r\n\r\n")

        val entrySha256 = LinkedHashMap<String, String>()
        val entrySha1 = LinkedHashMap<String, String>()

        for ((name, data) in files) {
            val d256 = Base64.getEncoder().encodeToString(sha256.digest(data))
            val d1 = Base64.getEncoder().encodeToString(sha1.digest(data))
            entrySha256[name] = d256
            entrySha1[name] = d1

            manifestSb.append("Name: ").append(name).append("\r\n")
            manifestSb.append("SHA-256-Digest: ").append(d256).append("\r\n")
            manifestSb.append("SHA1-Digest: ").append(d1).append("\r\n\r\n")
        }
        val manifestBytes = manifestSb.toString().toByteArray(Charsets.UTF_8)

        // 2. Generate CERT.SF
        val sfSb = StringBuilder()
        sfSb.append("Signature-Version: 1.0\r\nCreated-By: 1.0 (Web2APK)\r\n")
        val mfDigest256 = Base64.getEncoder().encodeToString(sha256.digest(manifestBytes))
        val mfDigest1 = Base64.getEncoder().encodeToString(sha1.digest(manifestBytes))
        sfSb.append("SHA-256-Digest-Manifest: ").append(mfDigest256).append("\r\n")
        sfSb.append("SHA1-Digest-Manifest: ").append(mfDigest1).append("\r\n\r\n")

        for ((name, d256) in entrySha256) {
            val entryBlock = "Name: $name\r\nSHA-256-Digest: $d256\r\nSHA1-Digest: ${entrySha1[name]}\r\n\r\n"
            val blockDigest = Base64.getEncoder().encodeToString(sha256.digest(entryBlock.toByteArray(Charsets.UTF_8)))
            val blockDigest1 = Base64.getEncoder().encodeToString(sha1.digest(entryBlock.toByteArray(Charsets.UTF_8)))
            sfSb.append("Name: ").append(name).append("\r\n")
            sfSb.append("SHA-256-Digest: ").append(blockDigest).append("\r\n")
            sfSb.append("SHA1-Digest: ").append(blockDigest1).append("\r\n\r\n")
        }
        val sfBytes = sfSb.toString().toByteArray(Charsets.UTF_8)

        // 3. Sign CERT.SF with RSA
        val sig = Signature.getInstance("SHA256withRSA")
        sig.initSign(privateKey)
        sig.update(sfBytes)
        val sigBytes = sig.sign()

        // 4. Build PKCS#7 block
        val pkcs7 = buildPkcs7Block(cert.encoded, sigBytes)

        // 5. Write output APK
        outputFile.parentFile?.mkdirs()
        ZipOutputStream(FileOutputStream(outputFile)).use { zos ->
            // Put META-INF entries first
            zos.putNextEntry(ZipEntry("META-INF/MANIFEST.MF"))
            zos.write(manifestBytes)
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("META-INF/CERT.SF"))
            zos.write(sfBytes)
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("META-INF/CERT.RSA"))
            zos.write(pkcs7)
            zos.closeEntry()

            // Put all other files
            for ((name, data) in files) {
                zos.putNextEntry(ZipEntry(name))
                zos.write(data)
                zos.closeEntry()
            }
        }
    }

    private fun loadKeystore(context: Context): Pair<PrivateKey, X509Certificate> {
        val ks = KeyStore.getInstance("PKCS12")
        val inputStream: InputStream = context.assets.open("template/signing.p12")
        inputStream.use {
            ks.load(it, "web2apk".toCharArray())
        }
        val key = ks.getKey("web2apk", "web2apk".toCharArray()) as PrivateKey
        val cert = ks.getCertificate("web2apk") as X509Certificate
        return Pair(key, cert)
    }

    private fun buildPkcs7Block(certEncoded: ByteArray, signatureBytes: ByteArray): ByteArray {
        val oidSignedData = byteArrayOf(0x06, 0x09, 0x2A, 0x86.toByte(), 0x48, 0x86.toByte(), 0xF7.toByte(), 0x0D, 0x01, 0x07, 0x02)
        val sha256Oid = derSequence(byteArrayOf(0x06, 0x09, 0x60, 0x86.toByte(), 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00))
        val digestAlgorithms = derSet(sha256Oid)
        val contentInfo = derSequence(byteArrayOf(0x06, 0x09, 0x2A, 0x86.toByte(), 0x48, 0x86.toByte(), 0xF7.toByte(), 0x0D, 0x01, 0x07, 0x01))
        val certs = derTagged(0, certEncoded)

        val siVersion = byteArrayOf(0x02, 0x01, 0x01)
        val issuerAndSerial = extractIssuerAndSerial(certEncoded)
        val digestAlgo = sha256Oid
        val sigAlgo = derSequence(byteArrayOf(0x06, 0x09, 0x2A, 0x86.toByte(), 0x48, 0x86.toByte(), 0xF7.toByte(), 0x0D, 0x01, 0x01, 0x01, 0x05, 0x00))
        val sigOctet = derOctetString(signatureBytes)

        val siContent = ByteArrayOutputStream()
        siContent.write(siVersion)
        siContent.write(issuerAndSerial)
        siContent.write(digestAlgo)
        siContent.write(sigAlgo)
        siContent.write(sigOctet)
        val signerInfo = derSequence(siContent.toByteArray())
        val signerInfos = derSet(signerInfo)

        val sd = ByteArrayOutputStream()
        sd.write(byteArrayOf(0x02, 0x01, 0x01))
        sd.write(digestAlgorithms)
        sd.write(contentInfo)
        sd.write(certs)
        sd.write(signerInfos)
        val signedDataSeq = derSequence(sd.toByteArray())

        val outer = ByteArrayOutputStream()
        outer.write(oidSignedData)
        outer.write(derTagged(0, signedDataSeq))
        return derSequence(outer.toByteArray())
    }

    private fun extractIssuerAndSerial(cert: ByteArray): ByteArray {
        var pos = 0
        var r = readHeader(cert, pos)
        pos = r[0]
        r = readHeader(cert, pos)
        pos = r[0]
        if ((cert[pos].toInt() and 0xFF) == 0xA0) {
            val v = readHeader(cert, pos)
            pos = v[0] + v[1]
        }
        val serialStart = pos
        val sn = readHeader(cert, pos)
        val serialLen = (sn[0] - serialStart) + sn[1]
        val serial = Arrays.copyOfRange(cert, serialStart, serialStart + serialLen)
        pos = serialStart + serialLen

        val sa = readHeader(cert, pos)
        pos = sa[0] + sa[1]

        val issuerStart = pos
        val isHeader = readHeader(cert, pos)
        val issuerLen = (isHeader[0] - issuerStart) + isHeader[1]
        val issuer = Arrays.copyOfRange(cert, issuerStart, issuerStart + issuerLen)

        val baos = ByteArrayOutputStream()
        baos.write(issuer)
        baos.write(serial)
        return derSequence(baos.toByteArray())
    }

    private fun readHeader(data: ByteArray, offset: Int): IntArray {
        var cur = offset
        cur++ // tag
        var len = data[cur++].toInt() and 0xFF
        if ((len and 0x80) != 0) {
            val count = len and 0x7F
            len = 0
            for (i in 0 until count) {
                len = (len shl 8) or (data[cur++].toInt() and 0xFF)
            }
        }
        return intArrayOf(cur, len)
    }

    private fun derLength(len: Int): ByteArray {
        return when {
            len < 128 -> byteArrayOf(len.toByte())
            len < 256 -> byteArrayOf(0x81.toByte(), len.toByte())
            len < 65536 -> byteArrayOf(0x82.toByte(), (len shr 8).toByte(), len.toByte())
            else -> byteArrayOf(0x83.toByte(), (len shr 16).toByte(), (len shr 8).toByte(), len.toByte())
        }
    }

    private fun derSequence(content: ByteArray): ByteArray {
        val baos = ByteArrayOutputStream()
        baos.write(0x30)
        baos.write(derLength(content.size))
        baos.write(content)
        return baos.toByteArray()
    }

    private fun derSet(content: ByteArray): ByteArray {
        val baos = ByteArrayOutputStream()
        baos.write(0x31)
        baos.write(derLength(content.size))
        baos.write(content)
        return baos.toByteArray()
    }

    private fun derOctetString(content: ByteArray): ByteArray {
        val baos = ByteArrayOutputStream()
        baos.write(0x04)
        baos.write(derLength(content.size))
        baos.write(content)
        return baos.toByteArray()
    }

    private fun derTagged(tag: Int, content: ByteArray): ByteArray {
        val baos = ByteArrayOutputStream()
        baos.write(0xA0 or (tag and 0x1F))
        baos.write(derLength(content.size))
        baos.write(content)
        return baos.toByteArray()
    }
}
