package com.example.builder

import android.content.Context
import com.example.data.WebProjectEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.util.LinkedHashMap
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ApkBuilder {

    data class BuildResult(
        val apkFile: File,
        val sizeBytes: Long,
        val appName: String,
        val packageName: String,
        val versionName: String,
        val timestamp: Long
    )

    suspend fun buildApk(
        context: Context,
        project: WebProjectEntity,
        onProgress: (step: String, progress: Float) -> Unit = { _, _ -> }
    ): BuildResult {
        onProgress("Reading base engine template...", 0.15f)
        val templateApkStream: InputStream = context.assets.open("template/template_base.apk")
        val templateBytes = templateApkStream.readBytes()
        templateApkStream.close()

        onProgress("Preparing app assets and configurations...", 0.35f)
        val entries = LinkedHashMap<String, ByteArray>()
        val zis = ZipInputStream(templateBytes.inputStream())
        var zipEntry: ZipEntry? = zis.nextEntry
        while (zipEntry != null) {
            val name = zipEntry.name
            if (!name.startsWith("META-INF/")) {
                val baos = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var n: Int
                while (zis.read(buf).also { n = it } != -1) {
                    baos.write(buf, 0, n)
                }
                entries[name] = baos.toByteArray()
            }
            zipEntry = zis.nextEntry
        }
        zis.close()

        onProgress("Rendering custom app icon...", 0.50f)
        val iconBytes = IconGenerator.generateIconPngBytes(
            context = context,
            customUri = project.iconUri,
            presetId = project.iconPreset,
            size = 192
        )
        entries["res/drawable/ic_launcher.png"] = iconBytes

        onProgress("Generating runtime configuration...", 0.65f)
        val configJson = JSONObject().apply {
            put("appName", project.name)
            put("packageName", project.packageName)
            put("versionName", project.versionName)
            put("versionCode", project.versionCode)
            put("url", project.targetUrl)
            put("isLocalHtml", project.sourceType.equals("HTML", ignoreCase = true))
            put("enableZoom", project.enableZoom)
            put("enablePullToRefresh", project.enablePullToRefresh)
            put("fullScreen", project.fullScreenMode)
            put("keepScreenOn", project.keepScreenOn)
            put("splashDuration", project.splashDurationSeconds * 1000)
            put("splashBgColor", project.splashBgColor)
            put("primaryColor", project.primaryColor)
            val permArray = JSONArray()
            for (p in project.getPermissionList()) {
                permArray.put(p)
            }
            put("permissions", permArray)
        }
        entries["assets/app_config.json"] = configJson.toString(2).toByteArray(StandardCharsets.UTF_8)

        if (project.sourceType.equals("HTML", ignoreCase = true)) {
            val htmlData = if (project.htmlContent.isBlank()) {
                "<!DOCTYPE html><html><body><h1>${project.name}</h1><p>Web2APK Ready</p></body></html>"
            } else {
                project.htmlContent
            }
            entries["assets/www/index.html"] = htmlData.toByteArray(StandardCharsets.UTF_8)
        }

        onProgress("Packaging unsigned APK archive...", 0.80f)
        val intermediateBaos = ByteArrayOutputStream()
        ZipOutputStream(intermediateBaos).use { zos ->
            for ((name, data) in entries) {
                zos.putNextEntry(ZipEntry(name))
                zos.write(data)
                zos.closeEntry()
            }
        }
        val intermediateApkBytes = intermediateBaos.toByteArray()

        onProgress("Signing APK with RSA certificate (v1 scheme)...", 0.90f)
        val safeName = project.name.replace("[^a-zA-Z0-9_-]".toRegex(), "_").ifBlank { "app" }
        val outputDir = File(context.getExternalFilesDir(null), "apks").apply { mkdirs() }
        val outputFile = File(outputDir, "${safeName}_v${project.versionName}.apk")

        ApkSigner.signApk(
            context = context,
            inputApkBytes = intermediateApkBytes,
            outputFile = outputFile
        )

        onProgress("Build finalized successfully!", 1.0f)
        return BuildResult(
            apkFile = outputFile,
            sizeBytes = outputFile.length(),
            appName = project.name,
            packageName = project.packageName,
            versionName = project.versionName,
            timestamp = System.currentTimeMillis()
        )
    }
}
