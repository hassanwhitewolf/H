package com.example.builder

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import java.io.ByteArrayOutputStream

object IconGenerator {

    enum class IconPreset(
        val displayName: String,
        val bgStart: Int,
        val bgEnd: Int,
        val accentColor: Int,
        val symbol: String
    ) {
        CYAN_GLOBE("Web Globe", 0xFF0F172A.toInt(), 0xFF0284C7.toInt(), 0xFF38BDF8.toInt(), "🌐"),
        GAMEPAD("Arcade", 0xFF18181B.toInt(), 0xFFD97706.toInt(), 0xFFFBBF24.toInt(), "🎮"),
        PUZZLE("Puzzle", 0xFF78350F.toInt(), 0xFFD97706.toInt(), 0xFFFEF3C7.toInt(), "🧩"),
        ROCKET("Rocket", 0xFF0F172A.toInt(), 0xFF7C3AED.toInt(), 0xFFA78BFA.toInt(), "🚀"),
        CALCULATOR("Utility", 0xFF1E1B4B.toInt(), 0xFF4338CA.toInt(), 0xFF818CF8.toInt(), "🧮"),
        CODE_BOX("HTML Code", 0xFF172554.toInt(), 0xFF2563EB.toInt(), 0xFF60A5FA.toInt(), "</>"),
        NEON_HEX("Cyber", 0xFF022C22.toInt(), 0xFF059669.toInt(), 0xFF34D399.toInt(), "⚡"),
        SHOPPING("Store", 0xFF831843.toInt(), 0xFFDB2777.toInt(), 0xFFF472B6.toInt(), "🛍️");

        companion object {
            fun fromId(id: String): IconPreset {
                return entries.firstOrNull { it.name.equals(id, ignoreCase = true) } ?: CYAN_GLOBE
            }
        }
    }

    fun generateIconBitmap(
        context: Context,
        customUri: String?,
        presetId: String,
        size: Int = 192
    ): Bitmap {
        if (!customUri.isNullOrBlank()) {
            try {
                val uri = Uri.parse(customUri)
                val stream = context.contentResolver.openInputStream(uri)
                if (stream != null) {
                    val original = BitmapFactory.decodeStream(stream)
                    stream.close()
                    if (original != null) {
                        return createSquircleFramedBitmap(original, size)
                    }
                }
            } catch (ignored: Exception) {}
        }

        val preset = IconPreset.fromId(presetId)
        return renderPresetBitmap(preset, size)
    }

    fun generateIconPngBytes(
        context: Context,
        customUri: String?,
        presetId: String,
        size: Int = 192
    ): ByteArray {
        val bitmap = generateIconBitmap(context, customUri, presetId, size)
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
        return baos.toByteArray()
    }

    private fun renderPresetBitmap(preset: IconPreset, size: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background squircle gradient
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val gradient = LinearGradient(
            0f, 0f, size.toFloat(), size.toFloat(),
            preset.bgStart, preset.bgEnd, Shader.TileMode.CLAMP
        )
        paint.shader = gradient
        val rect = RectF(0f, 0f, size.toFloat(), size.toFloat())
        val corner = size * 0.28f
        canvas.drawRoundRect(rect, corner, corner, paint)

        // Inner subtle rim light
        val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        rimPaint.style = Paint.Style.STROKE
        rimPaint.strokeWidth = size * 0.03f
        rimPaint.color = Color.argb(60, 255, 255, 255)
        val insetRect = RectF(rect)
        insetRect.inset(rimPaint.strokeWidth / 2, rimPaint.strokeWidth / 2)
        canvas.drawRoundRect(insetRect, corner - 2, corner - 2, rimPaint)

        // Draw Symbol / Emoji / Text
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = preset.accentColor

        if (preset.symbol == "</>") {
            textPaint.textSize = size * 0.38f
            textPaint.isFakeBoldText = true
            val fontMetrics = textPaint.fontMetrics
            val baseline = (size - fontMetrics.bottom - fontMetrics.top) / 2f
            canvas.drawText("</>", size / 2f, baseline, textPaint)
        } else {
            textPaint.textSize = size * 0.44f
            val fontMetrics = textPaint.fontMetrics
            val baseline = (size - fontMetrics.bottom - fontMetrics.top) / 2f
            canvas.drawText(preset.symbol, size / 2f, baseline, textPaint)
        }

        return bitmap
    }

    private fun createSquircleFramedBitmap(src: Bitmap, size: Int): Bitmap {
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rect = RectF(0f, 0f, size.toFloat(), size.toFloat())
        val corner = size * 0.28f

        val path = Path()
        path.addRoundRect(rect, corner, corner, Path.Direction.CW)
        canvas.clipPath(path)

        // Scale and center src
        val srcRect = android.graphics.Rect(0, 0, src.width, src.height)
        val dstRect = android.graphics.Rect(0, 0, size, size)
        canvas.drawBitmap(src, srcRect, dstRect, paint)

        // Rim
        val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        rimPaint.style = Paint.Style.STROKE
        rimPaint.strokeWidth = size * 0.03f
        rimPaint.color = Color.argb(80, 255, 255, 255)
        canvas.drawRoundRect(rect, corner, corner, rimPaint)

        return output
    }
}
