package com.example.builder

import android.content.Context
import com.example.data.WebProjectEntity
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object AndroidProjectExporter {

    suspend fun exportProjectZip(
        context: Context,
        project: WebProjectEntity
    ): File {
        val safeName = project.name.replace("[^a-zA-Z0-9_-]".toRegex(), "_").ifBlank { "app" }
        val outputDir = File(context.getExternalFilesDir(null), "exports").apply { mkdirs() }
        val zipFile = File(outputDir, "${safeName}_AndroidProject.zip")

        val iconBytes = IconGenerator.generateIconPngBytes(
            context = context,
            customUri = project.iconUri,
            presetId = project.iconPreset,
            size = 192
        )

        val pkg = project.packageName.ifBlank { "com.web2apk.app" }
        val pkgPath = pkg.replace('.', '/')

        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            // 1. Root settings.gradle.kts
            putZipText(zos, "settings.gradle.kts", """
                pluginManagement {
                    repositories {
                        google()
                        mavenCentral()
                        gradlePluginPortal()
                    }
                }
                dependencyResolutionManagement {
                    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
                    repositories {
                        google()
                        mavenCentral()
                    }
                }
                rootProject.name = "${project.name}"
                include(":app")
            """.trimIndent())

            // 2. Root build.gradle.kts
            putZipText(zos, "build.gradle.kts", """
                plugins {
                    id("com.android.application") version "8.5.2" apply false
                    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
                }
            """.trimIndent())

            // 3. gradle.properties
            putZipText(zos, "gradle.properties", """
                org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
                android.useAndroidX=true
                kotlin.code.style=official
            """.trimIndent())

            // 4. app/build.gradle.kts
            putZipText(zos, "app/build.gradle.kts", """
                plugins {
                    id("com.android.application")
                    id("org.jetbrains.kotlin.android")
                }

                android {
                    namespace = "$pkg"
                    compileSdk = 34

                    defaultConfig {
                        applicationId = "$pkg"
                        minSdk = 24
                        targetSdk = 34
                        versionCode = ${project.versionCode}
                        versionName = "${project.versionName}"
                    }

                    buildTypes {
                        release {
                            isMinifyEnabled = false
                            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
                        }
                    }
                    compileOptions {
                        sourceCompatibility = JavaVersion.VERSION_1_8
                        targetCompatibility = JavaVersion.VERSION_1_8
                    }
                    kotlinOptions {
                        jvmTarget = "1.8"
                    }
                }

                dependencies {
                    implementation("androidx.core:core-ktx:1.13.1")
                    implementation("androidx.appcompat:appcompat:1.7.0")
                    implementation("com.google.android.material:material:1.12.0")
                    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
                }
            """.trimIndent())

            // 5. app/src/main/AndroidManifest.xml
            val permissionsXml = StringBuilder()
            val perms = project.getPermissionList()
            if (perms.contains("INTERNET")) {
                permissionsXml.append("    <uses-permission android:name=\"android.permission.INTERNET\" />\n")
                permissionsXml.append("    <uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\" />\n")
            }
            if (perms.contains("STORAGE")) {
                permissionsXml.append("    <uses-permission android:name=\"android.permission.READ_EXTERNAL_STORAGE\" />\n")
                permissionsXml.append("    <uses-permission android:name=\"android.permission.WRITE_EXTERNAL_STORAGE\" />\n")
            }
            if (perms.contains("CAMERA")) {
                permissionsXml.append("    <uses-permission android:name=\"android.permission.CAMERA\" />\n")
            }
            if (perms.contains("LOCATION")) {
                permissionsXml.append("    <uses-permission android:name=\"android.permission.ACCESS_FINE_LOCATION\" />\n")
                permissionsXml.append("    <uses-permission android:name=\"android.permission.ACCESS_COARSE_LOCATION\" />\n")
            }
            if (perms.contains("MICROPHONE")) {
                permissionsXml.append("    <uses-permission android:name=\"android.permission.RECORD_AUDIO\" />\n")
            }
            if (perms.contains("NOTIFICATIONS")) {
                permissionsXml.append("    <uses-permission android:name=\"android.permission.POST_NOTIFICATIONS\" />\n")
            }
            if (perms.contains("VIBRATE")) {
                permissionsXml.append("    <uses-permission android:name=\"android.permission.VIBRATE\" />\n")
            }

            putZipText(zos, "app/src/main/AndroidManifest.xml", """
                <?xml version="1.0" encoding="utf-8"?>
                <manifest xmlns:android="http://schemas.android.com/apk/res/android">

                $permissionsXml
                    <application
                        android:allowBackup="true"
                        android:icon="@drawable/ic_launcher"
                        android:label="@string/app_name"
                        android:roundIcon="@drawable/ic_launcher"
                        android:supportsRtl="true"
                        android:usesCleartextTraffic="true"
                        android:theme="@style/Theme.WebApp">
                        <activity
                            android:name=".MainActivity"
                            android:exported="true"
                            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
                            android:windowSoftInputMode="adjustResize">
                            <intent-filter>
                                <action android:name="android.intent.action.MAIN" />
                                <category android:name="android.intent.category.LAUNCHER" />
                            </intent-filter>
                        </activity>
                    </application>

                </manifest>
            """.trimIndent())

            // 6. Kotlin MainActivity
            val isLocal = project.sourceType.equals("HTML", ignoreCase = true)
            putZipText(zos, "app/src/main/java/$pkgPath/MainActivity.kt", """
                package $pkg

                import android.annotation.SuppressLint
                import android.app.Activity
                import android.content.Intent
                import android.graphics.Color
                import android.net.Uri
                import android.os.Bundle
                import android.view.KeyEvent
                import android.view.View
                import android.view.ViewGroup
                import android.view.Window
                import android.view.WindowManager
                import android.webkit.*
                import android.widget.FrameLayout
                import android.widget.ProgressBar

                class MainActivity : Activity() {
                    private lateinit var webView: WebView
                    private lateinit var progressBar: ProgressBar

                    @SuppressLint("SetJavaScriptEnabled")
                    override fun onCreate(savedInstanceState: Bundle?) {
                        super.onCreate(savedInstanceState)

                        ${if (project.fullScreenMode) "requestWindowFeature(Window.FEATURE_NO_TITLE)\nwindow.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)" else ""}
                        ${if (project.keepScreenOn) "window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)" else ""}

                        val root = FrameLayout(this).apply {
                            layoutParams = FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        }

                        webView = WebView(this).apply {
                            layoutParams = FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        }

                        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 8)
                            max = 100
                            visibility = View.GONE
                        }

                        root.addView(webView)
                        root.addView(progressBar)
                        setContentView(root)

                        webView.settings.apply {
                            javaScriptEnabled = ${project.enableJavaScript}
                            domStorageEnabled = ${project.enableDomStorage}
                            databaseEnabled = true
                            allowFileAccess = true
                            allowContentAccess = true
                            builtInZoomControls = ${project.enableZoom}
                            displayZoomControls = false
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            setGeolocationEnabled(true)
                        }

                        webView.webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                val url = request?.url?.toString() ?: return false
                                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("file://")) {
                                    return false
                                }
                                return try {
                                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                                    true
                                } catch (e: Exception) {
                                    true
                                }
                            }
                        }

                        webView.webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                if (newProgress < 100) {
                                    progressBar.visibility = View.VISIBLE
                                    progressBar.progress = newProgress
                                } else {
                                    progressBar.visibility = View.GONE
                                }
                            }
                            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                                callback?.invoke(origin, true, false)
                            }
                        }

                        ${if (isLocal) "webView.loadUrl(\"file:///android_asset/www/index.html\")" else "webView.loadUrl(\"${project.targetUrl}\")"}
                    }

                    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
                        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
                            webView.goBack()
                            return true
                        }
                        return super.onKeyDown(keyCode, event)
                    }
                }
            """.trimIndent())

            // 7. Resources: strings.xml, themes.xml, ic_launcher.png
            putZipText(zos, "app/src/main/res/values/strings.xml", """
                <resources>
                    <string name="app_name">${project.name}</string>
                </resources>
            """.trimIndent())

            putZipText(zos, "app/src/main/res/values/themes.xml", """
                <resources>
                    <style name="Theme.WebApp" parent="android:Theme.Material.Light.NoActionBar">
                        <item name="android:statusBarColor">${project.splashBgColor}</item>
                    </style>
                </resources>
            """.trimIndent())

            // Put icon
            zos.putNextEntry(ZipEntry("app/src/main/res/drawable/ic_launcher.png"))
            zos.write(iconBytes)
            zos.closeEntry()

            // 8. If HTML project, include www/index.html
            if (isLocal) {
                putZipText(zos, "app/src/main/assets/www/index.html", project.htmlContent.ifBlank { "<h1>${project.name}</h1>" })
            }

            // 9. README.md
            putZipText(zos, "README.md", """
                # ${project.name} (Android Project)

                Generated by **Web2APK Builder**.

                ## Getting Started
                1. Open this folder in **Android Studio**.
                2. Let Gradle sync project dependencies.
                3. Connect an Android phone or launch an emulator.
                4. Click **Run > Run 'app'** to launch.

                ## Building Release APK / AAB
                - To build APK: `./gradlew assembleRelease`
                - To build Google Play Bundle: `./gradlew bundleRelease`
            """.trimIndent())
        }

        return zipFile
    }

    private fun putZipText(zos: ZipOutputStream, path: String, text: String) {
        zos.putNextEntry(ZipEntry(path))
        zos.write(text.toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()
    }
}
