package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00E5FF)
val ElectricViolet = Color(0xFF7C4DFF)
val NeonMint = Color(0xFF00E676)
val AmberGold = Color(0xFFFFB300)
val DangerRed = Color(0xFFFF5252)

val DarkBackground = Color(0xFF0B0E17)
val DarkSurface = Color(0xFF131722)
val DarkSurfaceVariant = Color(0xFF1C2234)
val DarkSurfaceHighlight = Color(0xFF262E45)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF2F6)
val LightPrimary = Color(0xFF0284C7)
val LightSecondary = Color(0xFF6366F1)
