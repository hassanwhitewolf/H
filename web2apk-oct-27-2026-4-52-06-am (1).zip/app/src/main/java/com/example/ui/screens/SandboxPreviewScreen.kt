package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.WebProjectEntity
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonMint
import com.example.viewmodel.Web2ApkViewModel

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SandboxPreviewScreen(
    project: WebProjectEntity,
    viewModel: Web2ApkViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var loadProgress by remember { mutableFloatStateOf(0f) }
    var currentUrl by remember { mutableStateOf(project.targetUrl) }
    var isDesktopMode by remember { mutableStateOf(false) }
    var showConsoleLogs by remember { mutableStateOf(false) }
    var isDeviceFrameEnabled by remember { mutableStateOf(true) }

    val consoleLogs by viewModel.consoleLogs.collectAsState()

    BackHandler {
        if (webViewInstance?.canGoBack() == true) {
            webViewInstance?.goBack()
        } else {
            onBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(project.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            if (project.sourceType.equals("HTML", ignoreCase = true)) "Offline HTML5 Sandbox" else currentUrl,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { isDesktopMode = !isDesktopMode },
                        modifier = Modifier.testTag("desktop_mode_toggle_btn")
                    ) {
                        Icon(
                            imageVector = if (isDesktopMode) Icons.Default.Laptop else Icons.Default.Smartphone,
                            contentDescription = "Viewport Mode",
                            tint = if (isDesktopMode) CyberCyan else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = { showConsoleLogs = !showConsoleLogs },
                        modifier = Modifier.testTag("console_logs_toggle_btn")
                    ) {
                        BadgedBox(badge = {
                            if (consoleLogs.isNotEmpty()) {
                                Badge(containerColor = CyberCyan) { Text("${consoleLogs.size.coerceAtMost(99)}") }
                            }
                        }) {
                            Icon(Icons.Default.Terminal, contentDescription = "Console Logs", tint = ElectricViolet)
                        }
                    }

                    Button(
                        onClick = { viewModel.buildApk(project) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color(0xFF003840)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.padding(end = 8.dp).height(38.dp).testTag("sandbox_build_apk_btn")
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Build APK", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { webViewInstance?.goBack() },
                            enabled = canGoBack
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                        IconButton(
                            onClick = { webViewInstance?.goForward() },
                            enabled = canGoForward
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Forward")
                        }
                        IconButton(
                            onClick = { webViewInstance?.reload() }
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reload")
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = isDeviceFrameEnabled,
                            onClick = { isDeviceFrameEnabled = !isDeviceFrameEnabled },
                            label = { Text("Phone Bezel", fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Loading Indicator
            AnimatedVisibility(visible = isLoading) {
                LinearProgressIndicator(
                    progress = { loadProgress },
                    color = CyberCyan,
                    modifier = Modifier.fillMaxWidth().height(3.dp)
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(if (isDeviceFrameEnabled) 12.dp else 0.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = if (isDeviceFrameEnabled) {
                        Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(28.dp))
                            .border(3.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(28.dp))
                            .background(Color.Black)
                    } else {
                        Modifier.fillMaxSize()
                    }
                ) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    databaseEnabled = true
                                    allowFileAccess = true
                                    allowContentAccess = true
                                    builtInZoomControls = project.enableZoom
                                    displayZoomControls = false
                                    useWideViewPort = true
                                    loadWithOverviewMode = true
                                    setGeolocationEnabled(true)
                                }

                                webViewClient = object : WebViewClient() {
                                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                        isLoading = true
                                        currentUrl = url ?: ""
                                        canGoBack = view?.canGoBack() ?: false
                                        canGoForward = view?.canGoForward() ?: false
                                    }

                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        isLoading = false
                                        currentUrl = url ?: ""
                                        canGoBack = view?.canGoBack() ?: false
                                        canGoForward = view?.canGoForward() ?: false
                                    }
                                }

                                webChromeClient = object : WebChromeClient() {
                                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                        loadProgress = newProgress / 100f
                                    }

                                    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                                        consoleMessage?.let {
                                            viewModel.addConsoleLog(
                                                level = it.messageLevel().name,
                                                message = it.message(),
                                                line = it.lineNumber()
                                            )
                                        }
                                        return true
                                    }

                                    override fun onGeolocationPermissionsShowPrompt(
                                        origin: String?,
                                        callback: GeolocationPermissions.Callback?
                                    ) {
                                        callback?.invoke(origin, true, false)
                                    }
                                }

                                webViewInstance = this

                                if (project.sourceType.equals("HTML", ignoreCase = true)) {
                                    loadDataWithBaseURL("https://localhost/", project.htmlContent, "text/html", "UTF-8", null)
                                } else {
                                    loadUrl(project.targetUrl)
                                }
                            }
                        },
                        update = { view ->
                            val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                            view.settings.userAgentString = if (isDesktopMode) desktopUa else null
                        },
                        modifier = Modifier.fillMaxSize().testTag("sandbox_webview")
                    )

                    // Phone Notch simulation if bezel enabled
                    if (isDeviceFrameEnabled) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 8.dp)
                                .width(90.dp)
                                .height(18.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .background(Color(0xFF161922))
                        )
                    }
                }
            }

            // Real-time Console Log Drawer
            AnimatedVisibility(visible = showConsoleLogs) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("JavaScript Console Logs", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CyberCyan)
                            Row {
                                TextButton(onClick = { viewModel.clearConsoleLogs() }) {
                                    Text("Clear", fontSize = 12.sp)
                                }
                                IconButton(onClick = { showConsoleLogs = false }) {
                                    Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        if (consoleLogs.isEmpty()) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                Text("No console logs yet. Trigger actions on the web page to see logs.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        } else {
                            LazyColumn(modifier = Modifier.fillMaxSize()) {
                                items(consoleLogs, key = { it.id }) { log ->
                                    val color = when (log.level) {
                                        "ERROR" -> MaterialTheme.colorScheme.error
                                        "WARNING" -> Color(0xFFFFB300)
                                        else -> NeonMint
                                    }
                                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                        Text("[${log.level}]", color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(log.message, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurface)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
