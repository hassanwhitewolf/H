package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.builder.IconGenerator
import com.example.data.WebProjectEntity
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonMint
import com.example.viewmodel.Web2ApkViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectEditorScreen(
    project: WebProjectEntity,
    viewModel: Web2ApkViewModel,
    onBack: () -> Unit,
    onTestSandbox: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }

    // Form states
    var appName by remember(project.id) { mutableStateOf(project.name) }
    var packageName by remember(project.id) { mutableStateOf(project.packageName) }
    var versionName by remember(project.id) { mutableStateOf(project.versionName) }
    var versionCode by remember(project.id) { mutableIntStateOf(project.versionCode) }
    var sourceType by remember(project.id) { mutableStateOf(project.sourceType) }
    var targetUrl by remember(project.id) { mutableStateOf(project.targetUrl) }
    var htmlContent by remember(project.id) { mutableStateOf(project.htmlContent) }
    var customIconUri by remember(project.id) { mutableStateOf(project.iconUri) }
    var iconPreset by remember(project.id) { mutableStateOf(project.iconPreset) }
    var enableZoom by remember(project.id) { mutableStateOf(project.enableZoom) }
    var enablePullToRefresh by remember(project.id) { mutableStateOf(project.enablePullToRefresh) }
    var fullScreenMode by remember(project.id) { mutableStateOf(project.fullScreenMode) }
    var keepScreenOn by remember(project.id) { mutableStateOf(project.keepScreenOn) }
    var splashDuration by remember(project.id) { mutableIntStateOf(project.splashDurationSeconds) }

    fun commitCurrentChanges() {
        val updated = project.copy(
            name = appName,
            packageName = packageName,
            versionName = versionName,
            versionCode = versionCode,
            sourceType = sourceType,
            targetUrl = targetUrl,
            htmlContent = htmlContent,
            iconUri = customIconUri,
            iconPreset = iconPreset,
            enableZoom = enableZoom,
            enablePullToRefresh = enablePullToRefresh,
            fullScreenMode = fullScreenMode,
            keepScreenOn = keepScreenOn,
            splashDurationSeconds = splashDuration
        )
        viewModel.updateProject(updated)
    }

    // Photo picker for custom icon
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            customIconUri = uri.toString()
            commitCurrentChanges()
        }
    }

    // Document picker for local HTML file
    val htmlFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importHtmlFile(uri, project)
            sourceType = "HTML"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(appName.ifBlank { "Project Editor" }, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(packageName, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        commitCurrentChanges()
                        onBack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        commitCurrentChanges()
                        viewModel.exportProjectZip(project)
                    }) {
                        Icon(Icons.Default.Archive, contentDescription = "Export Zip", tint = ElectricViolet)
                    }
                    IconButton(onClick = {
                        commitCurrentChanges()
                        viewModel.buildApk(project)
                    }) {
                        Icon(Icons.Default.Build, contentDescription = "Build APK", tint = CyberCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            commitCurrentChanges()
                            onTestSandbox()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(46.dp).testTag("editor_test_sandbox_btn")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Live Sandbox", fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = {
                            commitCurrentChanges()
                            viewModel.buildApk(project)
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color(0xFF003840)),
                        modifier = Modifier.weight(1f).height(46.dp).testTag("editor_build_apk_btn")
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Build APK", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = CyberCyan,
                divider = { HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant) }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("1. Content & Source", fontSize = 13.sp) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("2. Custom Icon", fontSize = 13.sp) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("3. Permissions (${project.getPermissionList().size})", fontSize = 13.sp) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("4. WebView UX", fontSize = 13.sp) }
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedTab) {
                    0 -> SourceAndMetaTab(
                        appName = appName,
                        onAppNameChange = {
                            appName = it
                            if (packageName.startsWith("com.web2apk.")) {
                                val clean = it.lowercase().replace("[^a-z0-9]".toRegex(), "")
                                packageName = "com.web2apk.$clean"
                            }
                            commitCurrentChanges()
                        },
                        packageName = packageName,
                        onPackageNameChange = {
                            packageName = it
                            commitCurrentChanges()
                        },
                        versionName = versionName,
                        onVersionNameChange = {
                            versionName = it
                            commitCurrentChanges()
                        },
                        sourceType = sourceType,
                        onSourceTypeChange = {
                            sourceType = it
                            commitCurrentChanges()
                        },
                        targetUrl = targetUrl,
                        onTargetUrlChange = {
                            targetUrl = it
                            commitCurrentChanges()
                        },
                        htmlContent = htmlContent,
                        onHtmlContentChange = {
                            htmlContent = it
                            commitCurrentChanges()
                        },
                        onImportHtmlFile = {
                            htmlFilePickerLauncher.launch(arrayOf("text/html", "text/plain", "*/*"))
                        },
                        onLoadSample = { sampleId ->
                            val updated = viewModel.loadSampleIntoProject(sampleId, project)
                            appName = updated.name
                            packageName = updated.packageName
                            sourceType = updated.sourceType
                            htmlContent = updated.htmlContent
                            iconPreset = updated.iconPreset
                        }
                    )

                    1 -> IconStudioTab(
                        customIconUri = customIconUri,
                        iconPreset = iconPreset,
                        onSelectPreset = { preset ->
                            iconPreset = preset
                            customIconUri = null
                            commitCurrentChanges()
                        },
                        onPickPhoto = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onClearCustom = {
                            customIconUri = null
                            commitCurrentChanges()
                        }
                    )

                    2 -> PermissionsManagerTab(
                        project = project,
                        onToggle = { perm ->
                            viewModel.togglePermission(project, perm)
                        }
                    )

                    3 -> WebviewSettingsTab(
                        enableZoom = enableZoom,
                        onEnableZoomChange = { enableZoom = it; commitCurrentChanges() },
                        enablePullToRefresh = enablePullToRefresh,
                        onEnablePullToRefreshChange = { enablePullToRefresh = it; commitCurrentChanges() },
                        fullScreenMode = fullScreenMode,
                        onFullScreenModeChange = { fullScreenMode = it; commitCurrentChanges() },
                        keepScreenOn = keepScreenOn,
                        onKeepScreenOnChange = { keepScreenOn = it; commitCurrentChanges() },
                        splashDuration = splashDuration,
                        onSplashDurationChange = { splashDuration = it; commitCurrentChanges() }
                    )
                }
            }
        }
    }
}

@Composable
private fun SourceAndMetaTab(
    appName: String,
    onAppNameChange: (String) -> Unit,
    packageName: String,
    onPackageNameChange: (String) -> Unit,
    versionName: String,
    onVersionNameChange: (String) -> Unit,
    sourceType: String,
    onSourceTypeChange: (String) -> Unit,
    targetUrl: String,
    onTargetUrlChange: (String) -> Unit,
    htmlContent: String,
    onHtmlContentChange: (String) -> Unit,
    onImportHtmlFile: () -> Unit,
    onLoadSample: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("App Identity", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CyberCyan)

            OutlinedTextField(
                value = appName,
                onValueChange = onAppNameChange,
                label = { Text("App Name") },
                modifier = Modifier.fillMaxWidth().testTag("editor_app_name_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            OutlinedTextField(
                value = packageName,
                onValueChange = onPackageNameChange,
                label = { Text("Package Name (Application ID)") },
                modifier = Modifier.fillMaxWidth().testTag("editor_package_name_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            OutlinedTextField(
                value = versionName,
                onValueChange = onVersionNameChange,
                label = { Text("Version Name") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
        }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Content Source", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = ElectricViolet)

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = sourceType.equals("URL", ignoreCase = true),
                    onClick = { onSourceTypeChange("URL") },
                    label = { Text("🌐 Website URL") },
                    modifier = Modifier.weight(1f),
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = CyberCyan.copy(alpha = 0.2f), selectedLabelColor = CyberCyan)
                )
                FilterChip(
                    selected = sourceType.equals("HTML", ignoreCase = true),
                    onClick = { onSourceTypeChange("HTML") },
                    label = { Text("⚡ HTML File / Code") },
                    modifier = Modifier.weight(1f),
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ElectricViolet.copy(alpha = 0.2f), selectedLabelColor = ElectricViolet)
                )
            }

            if (sourceType.equals("URL", ignoreCase = true)) {
                OutlinedTextField(
                    value = targetUrl,
                    onValueChange = onTargetUrlChange,
                    label = { Text("Target Website URL") },
                    placeholder = { Text("https://example.com") },
                    modifier = Modifier.fillMaxWidth().testTag("editor_target_url_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Text("Quick Presets:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SuggestionChip(
                        onClick = { onTargetUrlChange("https://en.m.wikipedia.org") },
                        label = { Text("Wikipedia", fontSize = 11.sp) }
                    )
                    SuggestionChip(
                        onClick = { onTargetUrlChange("https://news.ycombinator.com") },
                        label = { Text("HackerNews", fontSize = 11.sp) }
                    )
                    SuggestionChip(
                        onClick = { onTargetUrlChange("https://dev.to") },
                        label = { Text("Dev.to", fontSize = 11.sp) }
                    )
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = onImportHtmlFile,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).testTag("import_html_file_btn")
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Import .html File", fontSize = 12.sp)
                    }
                }

                Text("Or Choose Demo Template:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SuggestionChip(onClick = { onLoadSample("FLAPPY") }, label = { Text("🎮 Cyber Bird", fontSize = 11.sp) })
                    SuggestionChip(onClick = { onLoadSample("2048") }, label = { Text("🧩 2048", fontSize = 11.sp) })
                    SuggestionChip(onClick = { onLoadSample("PORTFOLIO") }, label = { Text("🚀 Portfolio", fontSize = 11.sp) })
                    SuggestionChip(onClick = { onLoadSample("CALCULATOR") }, label = { Text("🧮 Calc", fontSize = 11.sp) })
                }

                // Quick Tag Helpers
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { onHtmlContentChange(htmlContent + "\n<h1>Title</h1>") }) { Text("+<h1>") }
                    TextButton(onClick = { onHtmlContentChange(htmlContent + "\n<button onclick=\"alert('Hi!')\">Click</button>") }) { Text("+<button>") }
                    TextButton(onClick = { onHtmlContentChange(htmlContent + "\n<script>\n  console.log('App Loaded');\n</script>") }) { Text("+<script>") }
                }

                OutlinedTextField(
                    value = htmlContent,
                    onValueChange = onHtmlContentChange,
                    label = { Text("HTML / CSS / JavaScript Code") },
                    modifier = Modifier.fillMaxWidth().height(260.dp).testTag("editor_html_code_input"),
                    shape = RoundedCornerShape(12.dp),
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                )
            }
        }
    }
}

@Composable
private fun IconStudioTab(
    customIconUri: String?,
    iconPreset: String,
    onSelectPreset: (String) -> Unit,
    onPickPhoto: () -> Unit,
    onClearCustom: () -> Unit
) {
    val context = LocalContext.current
    val currentBitmap = remember(customIconUri, iconPreset) {
        IconGenerator.generateIconBitmap(context, customIconUri, iconPreset, size = 180)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(20.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("App Icon Preview", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CyberCyan)
            Spacer(modifier = Modifier.height(16.dp))

            Image(
                bitmap = currentBitmap.asImageBitmap(),
                contentDescription = "App Icon",
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .border(2.dp, CyberCyan, RoundedCornerShape(22.dp))
            )

            Spacer(modifier = Modifier.height(18.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onPickPhoto,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color(0xFF003840)),
                    modifier = Modifier.testTag("pick_icon_photo_btn")
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Pick Image from Gallery", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                if (customIconUri != null) {
                    OutlinedButton(onClick = onClearCustom, shape = RoundedCornerShape(12.dp)) {
                        Text("Reset")
                    }
                }
            }
        }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Or Choose Built-in Icon Preset", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                IconGenerator.IconPreset.entries.chunked(4).forEach { rowPresets ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (preset in rowPresets) {
                            val isSelected = iconPreset == preset.name && customIconUri == null
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) CyberCyan.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (isSelected) ButtonDefaults.outlinedButtonBorder else null,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onSelectPreset(preset.name) }
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(preset.symbol, fontSize = 24.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(preset.displayName, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionsManagerTab(
    project: WebProjectEntity,
    onToggle: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("App Permissions Configuration", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NeonMint)
            Text(
                "Enable the hardware and device capabilities required by this web app:",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            PermissionToggleRow(
                icon = Icons.Default.Public,
                title = "Internet & Network Access",
                desc = "Required to fetch web pages, remote REST APIs, and external images.",
                tag = "INTERNET",
                isEnabled = project.hasPermission("INTERNET"),
                onToggle = { onToggle("INTERNET") }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

            PermissionToggleRow(
                icon = Icons.Default.Folder,
                title = "Storage & Downloads",
                desc = "Allows web app to download files, images, and access local storage.",
                tag = "STORAGE",
                isEnabled = project.hasPermission("STORAGE"),
                onToggle = { onToggle("STORAGE") }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

            PermissionToggleRow(
                icon = Icons.Default.CameraAlt,
                title = "Camera Access",
                desc = "Allows HTML5 camera capture, QR scanning, and WebRTC video chat.",
                tag = "CAMERA",
                isEnabled = project.hasPermission("CAMERA"),
                onToggle = { onToggle("CAMERA") }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

            PermissionToggleRow(
                icon = Icons.Default.LocationOn,
                title = "GPS Geolocation",
                desc = "Allows navigator.geolocation for maps, locations, and weather apps.",
                tag = "LOCATION",
                isEnabled = project.hasPermission("LOCATION"),
                onToggle = { onToggle("LOCATION") }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

            PermissionToggleRow(
                icon = Icons.Default.Mic,
                title = "Microphone & Audio",
                desc = "Allows voice recording and WebRTC audio chat.",
                tag = "MICROPHONE",
                isEnabled = project.hasPermission("MICROPHONE"),
                onToggle = { onToggle("MICROPHONE") }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

            PermissionToggleRow(
                icon = Icons.Default.Notifications,
                title = "Push Notifications",
                desc = "Enables web push notifications and alert popups.",
                tag = "NOTIFICATIONS",
                isEnabled = project.hasPermission("NOTIFICATIONS"),
                onToggle = { onToggle("NOTIFICATIONS") }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

            PermissionToggleRow(
                icon = Icons.Default.Vibration,
                title = "Haptic Vibration",
                desc = "Allows game vibrations via navigator.vibrate().",
                tag = "VIBRATE",
                isEnabled = project.hasPermission("VIBRATE"),
                onToggle = { onToggle("VIBRATE") }
            )
        }
    }
}

@Composable
private fun PermissionToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    tag: String,
    isEnabled: Boolean,
    onToggle: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
            .padding(vertical = 4.dp)
            .testTag("perm_row_$tag")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(if (isEnabled) NeonMint.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isEnabled) NeonMint else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Switch(
            checked = isEnabled,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(checkedThumbColor = NeonMint, checkedTrackColor = NeonMint.copy(alpha = 0.4f))
        )
    }
}

@Composable
private fun WebviewSettingsTab(
    enableZoom: Boolean,
    onEnableZoomChange: (Boolean) -> Unit,
    enablePullToRefresh: Boolean,
    onEnablePullToRefreshChange: (Boolean) -> Unit,
    fullScreenMode: Boolean,
    onFullScreenModeChange: (Boolean) -> Unit,
    keepScreenOn: Boolean,
    onKeepScreenOnChange: (Boolean) -> Unit,
    splashDuration: Int,
    onSplashDurationChange: (Int) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("WebView UX & Native Features", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CyberCyan)

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Fullscreen Mode", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Hides the status bar for full immersive canvas or games", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = fullScreenMode, onCheckedChange = onFullScreenModeChange)
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Keep Screen On", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Prevents phone display from sleeping while app is open", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = keepScreenOn, onCheckedChange = onKeepScreenOnChange)
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Pull-To-Refresh", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Swipe down from top to reload website", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = enablePullToRefresh, onCheckedChange = onEnablePullToRefreshChange)
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Pinch Zoom Controls", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Allows multi-touch pinch to zoom web page", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = enableZoom, onCheckedChange = onEnableZoomChange)
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Column {
                Text("Splash Screen Duration: $splashDuration seconds", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Slider(
                    value = splashDuration.toFloat(),
                    onValueChange = { onSplashDurationChange(it.toInt()) },
                    valueRange = 0f..4f,
                    steps = 3
                )
            }
        }
    }
}
