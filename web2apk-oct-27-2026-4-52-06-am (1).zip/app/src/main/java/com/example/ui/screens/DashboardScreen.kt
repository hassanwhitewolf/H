package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.WebProjectEntity
import com.example.ui.components.ProjectCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonMint
import com.example.viewmodel.Web2ApkViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: Web2ApkViewModel,
    onOpenProject: (WebProjectEntity) -> Unit,
    onTestSandbox: (WebProjectEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val projects by viewModel.projects.collectAsState()
    var selectedFilter by remember { mutableStateOf("ALL") }
    var quickUrlInput by remember { mutableStateOf("") }
    var showQuickUrlDialog by remember { mutableStateOf(false) }

    val filteredProjects = remember(projects, selectedFilter) {
        when (selectedFilter) {
            "URL" -> projects.filter { it.sourceType.equals("URL", ignoreCase = true) }
            "HTML" -> projects.filter { it.sourceType.equals("HTML", ignoreCase = true) }
            else -> projects
        }
    }

    val urlCount = projects.count { it.sourceType.equals("URL", ignoreCase = true) }
    val htmlCount = projects.count { it.sourceType.equals("HTML", ignoreCase = true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(listOf(CyberCyan, ElectricViolet))
                                )
                        ) {
                            Text(
                                "</>",
                                fontWeight = FontWeight.Bold,
                                color = Color.Black,
                                fontSize = 16.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                "Web2APK Studio",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                            )
                            Text(
                                "HTML & URL to Native Android APK",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val newProj = viewModel.createNewProject("URL")
                            onOpenProject(newProj)
                        },
                        modifier = Modifier.testTag("new_url_app_top_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddLink,
                            contentDescription = "New URL App",
                            tint = CyberCyan
                        )
                    }
                    IconButton(
                        onClick = {
                            val newProj = viewModel.createNewProject("HTML")
                            onOpenProject(newProj)
                        },
                        modifier = Modifier.testTag("new_html_app_top_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = "New HTML App",
                            tint = ElectricViolet
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showQuickUrlDialog = true },
                containerColor = CyberCyan,
                contentColor = Color(0xFF003840),
                modifier = Modifier.testTag("fab_quick_convert")
            ) {
                Icon(Icons.Default.Bolt, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Quick Convert", fontWeight = FontWeight.Bold)
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = innerPadding.calculateTopPadding() + 8.dp,
                bottom = innerPadding.calculateBottomPadding() + 80.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Hero Banner with Stats
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            Brush.horizontalGradient(listOf(CyberCyan.copy(alpha = 0.4f), ElectricViolet.copy(alpha = 0.4f))),
                            RoundedCornerShape(22.dp)
                        )
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    "App Compiler Ready",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = CyberCyan
                                    )
                                )
                                Text(
                                    "Generate real signed APKs on device",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                            Surface(
                                shape = CircleShape,
                                color = NeonMint.copy(alpha = 0.15f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(NeonMint)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("v1 Signed", color = NeonMint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("${projects.size}", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
                                    Text("Projects", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("$urlCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = CyberCyan)
                                    Text("Website URLs", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("$htmlCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = ElectricViolet)
                                    Text("Offline HTML", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Quick buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    val newProj = viewModel.createNewProject("URL")
                                    onOpenProject(newProj)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan.copy(alpha = 0.2f), contentColor = CyberCyan),
                                modifier = Modifier.weight(1f).height(42.dp)
                            ) {
                                Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add URL", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    val newProj = viewModel.createNewProject("HTML")
                                    onOpenProject(newProj)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet.copy(alpha = 0.2f), contentColor = ElectricViolet),
                                modifier = Modifier.weight(1f).height(42.dp)
                            ) {
                                Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add HTML", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Filter Chips
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = selectedFilter == "ALL",
                        onClick = { selectedFilter = "ALL" },
                        label = { Text("All Projects (${projects.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                            selectedLabelColor = CyberCyan
                        )
                    )
                    FilterChip(
                        selected = selectedFilter == "URL",
                        onClick = { selectedFilter = "URL" },
                        label = { Text("Websites ($urlCount)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                            selectedLabelColor = CyberCyan
                        )
                    )
                    FilterChip(
                        selected = selectedFilter == "HTML",
                        onClick = { selectedFilter = "HTML" },
                        label = { Text("HTML Apps ($htmlCount)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricViolet.copy(alpha = 0.2f),
                            selectedLabelColor = ElectricViolet
                        )
                    )
                }
            }

            // Projects List
            if (filteredProjects.isEmpty()) {
                item {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.FolderOpen,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "No projects in this category",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }
            } else {
                items(filteredProjects, key = { it.id }) { project ->
                    ProjectCard(
                        project = project,
                        onSelect = { onOpenProject(project) },
                        onTestSandbox = { onTestSandbox(project) },
                        onBuildApk = { viewModel.buildApk(project) },
                        onExportZip = { viewModel.exportProjectZip(project) },
                        onDuplicate = { viewModel.duplicateProject(project) },
                        onDelete = { viewModel.deleteProject(project) }
                    )
                }
            }
        }
    }

    // Quick Convert Dialog
    if (showQuickUrlDialog) {
        AlertDialog(
            onDismissRequest = { showQuickUrlDialog = false },
            title = { Text("Quick Convert Website URL", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Enter any website URL to turn it into an Android APK:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = quickUrlInput,
                        onValueChange = { quickUrlInput = it },
                        placeholder = { Text("https://mywebsite.com") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("quick_url_text_field"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SuggestionChip(
                            onClick = { quickUrlInput = "https://en.m.wikipedia.org" },
                            label = { Text("Wikipedia", fontSize = 11.sp) }
                        )
                        SuggestionChip(
                            onClick = { quickUrlInput = "https://news.ycombinator.com" },
                            label = { Text("HackerNews", fontSize = 11.sp) }
                        )
                        SuggestionChip(
                            onClick = { quickUrlInput = "https://github.com" },
                            label = { Text("GitHub", fontSize = 11.sp) }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = quickUrlInput.trim().let {
                            if (!it.startsWith("http://") && !it.startsWith("https://")) "https://$it" else it
                        }
                        val domain = try {
                            val uri = android.net.Uri.parse(trimmed)
                            uri.host?.replace("www.", "")?.replace(".com", "")?.replace(".org", "")?.replace(".", "_") ?: "website"
                        } catch (e: Exception) {
                            "website"
                        }
                        val name = domain.replaceFirstChar { it.uppercase() }
                        val newProj = viewModel.createNewProject("URL").copy(
                            name = name,
                            packageName = "com.web2apk.$domain",
                            targetUrl = trimmed
                        )
                        viewModel.updateProject(newProj)
                        showQuickUrlDialog = false
                        quickUrlInput = ""
                        onOpenProject(newProj)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color(0xFF003840))
                ) {
                    Text("Create Project", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuickUrlDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
