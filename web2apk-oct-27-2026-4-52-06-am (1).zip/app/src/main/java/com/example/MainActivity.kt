package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.WebProjectEntity
import com.example.ui.components.BuildDialog
import com.example.ui.components.ExportZipDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ProjectEditorScreen
import com.example.ui.screens.SandboxPreviewScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.BuildUiState
import com.example.viewmodel.ExportUiState
import com.example.viewmodel.Web2ApkViewModel

enum class AppScreen {
    DASHBOARD,
    EDITOR,
    SANDBOX
}

class MainActivity : ComponentActivity() {

    private val viewModel: Web2ApkViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIncomingIntent(intent)

        setContent {
            MyApplicationTheme {
                val selectedProject by viewModel.selectedProject.collectAsStateWithLifecycle()
                val buildState by viewModel.buildState.collectAsStateWithLifecycle()
                val exportState by viewModel.exportState.collectAsStateWithLifecycle()
                val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

                var currentScreen by remember { mutableStateOf(AppScreen.DASHBOARD) }

                LaunchedEffect(toastMessage) {
                    toastMessage?.let {
                        Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show()
                        viewModel.clearToast()
                    }
                }

                BackHandler(enabled = currentScreen != AppScreen.DASHBOARD) {
                    currentScreen = AppScreen.DASHBOARD
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "ScreenTransition"
                    ) { screen ->
                        when (screen) {
                            AppScreen.DASHBOARD -> {
                                DashboardScreen(
                                    viewModel = viewModel,
                                    onOpenProject = { project ->
                                        viewModel.selectProject(project)
                                        currentScreen = AppScreen.EDITOR
                                    },
                                    onTestSandbox = { project ->
                                        viewModel.selectProject(project)
                                        currentScreen = AppScreen.SANDBOX
                                    }
                                )
                            }

                            AppScreen.EDITOR -> {
                                val proj = selectedProject
                                if (proj != null) {
                                    ProjectEditorScreen(
                                        project = proj,
                                        viewModel = viewModel,
                                        onBack = { currentScreen = AppScreen.DASHBOARD },
                                        onTestSandbox = { currentScreen = AppScreen.SANDBOX }
                                    )
                                } else {
                                    currentScreen = AppScreen.DASHBOARD
                                }
                            }

                            AppScreen.SANDBOX -> {
                                val proj = selectedProject
                                if (proj != null) {
                                    SandboxPreviewScreen(
                                        project = proj,
                                        viewModel = viewModel,
                                        onBack = { currentScreen = AppScreen.EDITOR }
                                    )
                                } else {
                                    currentScreen = AppScreen.DASHBOARD
                                }
                            }
                        }
                    }

                    // Global Build and Export Modals
                    BuildDialog(
                        buildState = buildState,
                        viewModel = viewModel,
                        onDismiss = { viewModel.resetBuildState() }
                    )

                    ExportZipDialog(
                        exportState = exportState,
                        viewModel = viewModel,
                        onDismiss = { viewModel.resetExportState() }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        val type = intent.type

        if (Intent.ACTION_SEND == action && type != null) {
            if (type == "text/plain") {
                val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
                if (sharedText.startsWith("http://") || sharedText.startsWith("https://")) {
                    val newProj = viewModel.createNewProject("URL").copy(
                        targetUrl = sharedText,
                        name = "Shared Link"
                    )
                    viewModel.updateProject(newProj)
                    viewModel.selectProject(newProj)
                }
            } else if (type == "text/html") {
                val sharedHtml = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
                val newProj = viewModel.createNewProject("HTML").copy(
                    htmlContent = sharedHtml,
                    name = "Shared HTML"
                )
                viewModel.updateProject(newProj)
                viewModel.selectProject(newProj)
            }
        } else if (Intent.ACTION_VIEW == action) {
            val uri: Uri? = intent.data
            if (uri != null) {
                val newProj = viewModel.createNewProject("URL").copy(
                    targetUrl = uri.toString(),
                    name = uri.host ?: "Web App"
                )
                viewModel.updateProject(newProj)
                viewModel.selectProject(newProj)
            }
        }
    }
}
