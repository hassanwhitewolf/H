package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WebProjectDao {
    @Query("SELECT * FROM web_projects ORDER BY updatedAt DESC")
    fun getAllProjects(): Flow<List<WebProjectEntity>>

    @Query("SELECT * FROM web_projects WHERE id = :id LIMIT 1")
    fun getProjectById(id: String): Flow<WebProjectEntity?>

    @Query("SELECT * FROM web_projects WHERE id = :id LIMIT 1")
    suspend fun getProjectByIdSync(id: String): WebProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: WebProjectEntity)

    @Update
    suspend fun updateProject(project: WebProjectEntity)

    @Delete
    suspend fun deleteProject(project: WebProjectEntity)

    @Query("DELETE FROM web_projects WHERE id = :id")
    suspend fun deleteProjectById(id: String)
}
