package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.util.UUID

@Database(entities = [WebProjectEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun webProjectDao(): WebProjectDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "web2apk.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Pre-populate with default demo templates
                        CoroutineScope(Dispatchers.IO).launch {
                            val dao = getInstance(context).webProjectDao()
                            prepopulateProjects(context, dao)
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun prepopulateProjects(context: Context, dao: WebProjectDao) {
            val flappyHtml = readAsset(context, "samples/flappy_bird/index.html")
            val game2048Html = readAsset(context, "samples/game_2048/index.html")
            val portfolioHtml = readAsset(context, "samples/portfolio/index.html")
            val calcHtml = readAsset(context, "samples/calculator/index.html")

            val initialProjects = listOf(
                WebProjectEntity(
                    id = "demo_flappy_bird",
                    name = "Cyber Bird Game",
                    packageName = "com.arcade.cyberbird",
                    versionName = "1.0.0",
                    versionCode = 1,
                    sourceType = "HTML",
                    targetUrl = "index.html",
                    htmlContent = flappyHtml,
                    iconPreset = "GAMEPAD",
                    permissionsCsv = "INTERNET,VIBRATE",
                    enableJavaScript = true,
                    enableDomStorage = true,
                    fullScreenMode = true,
                    keepScreenOn = true,
                    splashBgColor = "#0F111A",
                    primaryColor = "#F39C12",
                    splashDurationSeconds = 1
                ),
                WebProjectEntity(
                    id = "demo_2048",
                    name = "2048 Puzzle",
                    packageName = "com.puzzle.game2048",
                    versionName = "2.1.0",
                    versionCode = 2,
                    sourceType = "HTML",
                    targetUrl = "index.html",
                    htmlContent = game2048Html,
                    iconPreset = "PUZZLE",
                    permissionsCsv = "STORAGE",
                    enableJavaScript = true,
                    enableDomStorage = true,
                    fullScreenMode = false,
                    keepScreenOn = false,
                    splashBgColor = "#FAF8EF",
                    primaryColor = "#8F7A66",
                    splashDurationSeconds = 1
                ),
                WebProjectEntity(
                    id = "demo_wiki",
                    name = "Wikipedia Mobile",
                    packageName = "org.web2apk.wikipedia",
                    versionName = "1.0.0",
                    versionCode = 1,
                    sourceType = "URL",
                    targetUrl = "https://en.m.wikipedia.org",
                    htmlContent = "",
                    iconPreset = "GLOBE",
                    permissionsCsv = "INTERNET,STORAGE",
                    enableJavaScript = true,
                    enableDomStorage = true,
                    enablePullToRefresh = true,
                    splashBgColor = "#12141C",
                    primaryColor = "#00E5FF",
                    splashDurationSeconds = 2
                ),
                WebProjectEntity(
                    id = "demo_portfolio",
                    name = "Apex Studio",
                    packageName = "com.studio.apex",
                    versionName = "1.0.0",
                    versionCode = 1,
                    sourceType = "HTML",
                    targetUrl = "index.html",
                    htmlContent = portfolioHtml,
                    iconPreset = "ROCKET",
                    permissionsCsv = "INTERNET",
                    enableJavaScript = true,
                    enableDomStorage = true,
                    enablePullToRefresh = true,
                    splashBgColor = "#0B0D17",
                    primaryColor = "#00E5FF",
                    splashDurationSeconds = 1
                ),
                WebProjectEntity(
                    id = "demo_calculator",
                    name = "Neo Calculator",
                    packageName = "com.tools.neocalculator",
                    versionName = "1.0.0",
                    versionCode = 1,
                    sourceType = "HTML",
                    targetUrl = "index.html",
                    htmlContent = calcHtml,
                    iconPreset = "CALCULATOR",
                    permissionsCsv = "VIBRATE",
                    enableJavaScript = true,
                    enableDomStorage = true,
                    fullScreenMode = false,
                    keepScreenOn = true,
                    splashBgColor = "#12141C",
                    primaryColor = "#7C4DFF",
                    splashDurationSeconds = 1
                )
            )

            for (project in initialProjects) {
                dao.insertProject(project)
            }
        }

        private fun readAsset(context: Context, path: String): String {
            return try {
                val inputStream: InputStream = context.assets.open(path)
                val bytes = inputStream.readBytes()
                inputStream.close()
                String(bytes, StandardCharsets.UTF_8)
            } catch (e: Exception) {
                ""
            }
        }
    }
}
