package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "web_projects")
data class WebProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val packageName: String,
    val versionName: String = "1.0.0",
    val versionCode: Int = 1,
    val sourceType: String = "URL", // "URL" or "HTML"
    val targetUrl: String = "https://example.com",
    val htmlContent: String = "",
    val iconUri: String? = null,
    val iconPreset: String = "CYAN_GLOBE", // preset identifier
    val permissionsCsv: String = "INTERNET", // comma-separated permissions
    val enableJavaScript: Boolean = true,
    val enableDomStorage: Boolean = true,
    val enableZoom: Boolean = false,
    val enablePullToRefresh: Boolean = true,
    val fullScreenMode: Boolean = false,
    val keepScreenOn: Boolean = false,
    val splashDurationSeconds: Int = 2,
    val splashBgColor: String = "#0F111A",
    val primaryColor: String = "#00E5FF",
    val userAgentType: String = "MOBILE", // MOBILE, DEFAULT, DESKTOP
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun getPermissionList(): List<String> {
        return if (permissionsCsv.isBlank()) emptyList() else permissionsCsv.split(",")
    }

    fun hasPermission(permission: String): Boolean {
        return getPermissionList().contains(permission)
    }
}
