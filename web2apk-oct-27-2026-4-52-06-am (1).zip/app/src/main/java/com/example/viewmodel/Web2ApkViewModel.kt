package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.builder.AndroidProjectExporter
import com.example.builder.ApkBuilder
import com.example.data.AppDatabase
import com.example.data.WebProjectEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.UUID

sealed interface BuildUiState {
    object Idle : BuildUiState
    data class Building(val step: String, val progress: Float) : BuildUiState
    data class Success(val result: ApkBuilder.BuildResult) : BuildUiState
    data class Error(val error: String) : BuildUiState
}

sealed interface ExportUiState {
    object Idle : ExportUiState
    object Exporting : ExportUiState
    data class Success(val zipFile: File) : ExportUiState
    data class Error(val error: String) : ExportUiState
}

data class ConsoleLogItem(
    val id: String = UUID.randomUUID().toString(),
    val level: String, // LOG, WARN, ERROR, INFO
    val message: String,
    val line: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

class Web2ApkViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val dao = db.webProjectDao()

    val projects: StateFlow<List<WebProjectEntity>> = dao.getAllProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedProject = MutableStateFlow<WebProjectEntity?>(null)
    val selectedProject: StateFlow<WebProjectEntity?> = _selectedProject.asStateFlow()

    private val _buildState = MutableStateFlow<BuildUiState>(BuildUiState.Idle)
    val buildState: StateFlow<BuildUiState> = _buildState.asStateFlow()

    private val _exportState = MutableStateFlow<ExportUiState>(ExportUiState.Idle)
    val exportState: StateFlow<ExportUiState> = _exportState.asStateFlow()

    private val _consoleLogs = MutableStateFlow<List<ConsoleLogItem>>(emptyList())
    val consoleLogs: StateFlow<List<ConsoleLogItem>> = _consoleLogs.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    fun clearToast() {
        _toastMessage.value = null
    }

    fun selectProject(project: WebProjectEntity?) {
        _selectedProject.value = project
    }

    fun createNewProject(sourceType: String = "URL"): WebProjectEntity {
        val id = "proj_" + UUID.randomUUID().toString().take(8)
        val defaultName = if (sourceType == "HTML") "New HTML App" else "My Web App"
        val safePkgName = "com.web2apk." + defaultName.lowercase().replace("[^a-z0-9]".toRegex(), "")
        val newProj = WebProjectEntity(
            id = id,
            name = defaultName,
            packageName = safePkgName,
            versionName = "1.0.0",
            versionCode = 1,
            sourceType = sourceType,
            targetUrl = if (sourceType == "HTML") "index.html" else "https://example.com",
            htmlContent = if (sourceType == "HTML") {
                "<!DOCTYPE html>\n<html>\n<head>\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <title>$defaultName</title>\n  <style>\n    body { background: #0f111a; color: #fff; font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; }\n    h1 { color: #00e5ff; }\n    button { background: #7c4dff; color: #fff; border: none; padding: 12px 24px; border-radius: 20px; font-weight: bold; cursor: pointer; }\n  </style>\n</head>\n<body>\n  <h1>Hello Web2APK!</h1>\n  <p>Your custom offline web app is live.</p>\n  <button onclick=\"alert('It works natively!')\">Tap Me</button>\n</body>\n</html>"
            } else "",
            iconPreset = if (sourceType == "HTML") "CODE_BOX" else "CYAN_GLOBE",
            permissionsCsv = "INTERNET",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertProject(newProj)
            withContext(Dispatchers.Main) {
                _selectedProject.value = newProj
            }
        }
        return newProj
    }

    fun updateProject(project: WebProjectEntity) {
        val updated = project.copy(updatedAt = System.currentTimeMillis())
        _selectedProject.value = updated
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertProject(updated)
        }
    }

    fun deleteProject(project: WebProjectEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteProject(project)
            if (_selectedProject.value?.id == project.id) {
                withContext(Dispatchers.Main) {
                    _selectedProject.value = null
                }
            }
        }
    }

    fun duplicateProject(project: WebProjectEntity) {
        val newId = "proj_" + UUID.randomUUID().toString().take(8)
        val copy = project.copy(
            id = newId,
            name = "${project.name} (Copy)",
            packageName = project.packageName + ".copy",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertProject(copy)
            withContext(Dispatchers.Main) {
                _toastMessage.value = "Project duplicated!"
            }
        }
    }

    fun loadSampleIntoProject(sampleId: String, current: WebProjectEntity): WebProjectEntity {
        val context = getApplication<Application>()
        val path = when (sampleId) {
            "FLAPPY" -> "samples/flappy_bird/index.html"
            "2048" -> "samples/game_2048/index.html"
            "PORTFOLIO" -> "samples/portfolio/index.html"
            "CALCULATOR" -> "samples/calculator/index.html"
            else -> "samples/portfolio/index.html"
        }
        val content = try {
            val stream = context.assets.open(path)
            val bytes = stream.readBytes()
            stream.close()
            String(bytes, StandardCharsets.UTF_8)
        } catch (e: Exception) {
            current.htmlContent
        }

        val updated = when (sampleId) {
            "FLAPPY" -> current.copy(
                name = "Cyber Bird Game",
                packageName = "com.arcade.cyberbird",
                sourceType = "HTML",
                htmlContent = content,
                iconPreset = "GAMEPAD",
                permissionsCsv = "INTERNET,VIBRATE",
                fullScreenMode = true,
                keepScreenOn = true
            )
            "2048" -> current.copy(
                name = "2048 Puzzle",
                packageName = "com.puzzle.game2048",
                sourceType = "HTML",
                htmlContent = content,
                iconPreset = "PUZZLE",
                permissionsCsv = "STORAGE"
            )
            "PORTFOLIO" -> current.copy(
                name = "Apex Studio",
                packageName = "com.studio.apex",
                sourceType = "HTML",
                htmlContent = content,
                iconPreset = "ROCKET",
                permissionsCsv = "INTERNET"
            )
            "CALCULATOR" -> current.copy(
                name = "Neo Calculator",
                packageName = "com.tools.calculator",
                sourceType = "HTML",
                htmlContent = content,
                iconPreset = "CALCULATOR",
                permissionsCsv = "VIBRATE",
                keepScreenOn = true
            )
            else -> current.copy(htmlContent = content)
        }
        updateProject(updated)
        _toastMessage.value = "Loaded template: ${updated.name}"
        return updated
    }

    fun importHtmlFile(uri: Uri, current: WebProjectEntity) {
        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val stream = context.contentResolver.openInputStream(uri)
                if (stream != null) {
                    val bytes = stream.readBytes()
                    stream.close()
                    val html = String(bytes, StandardCharsets.UTF_8)
                    val updated = current.copy(
                        sourceType = "HTML",
                        htmlContent = html,
                        updatedAt = System.currentTimeMillis()
                    )
                    updateProject(updated)
                    withContext(Dispatchers.Main) {
                        _toastMessage.value = "HTML file imported successfully (${bytes.size} bytes)"
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _toastMessage.value = "Failed to import HTML: ${e.message}"
                }
            }
        }
    }

    fun togglePermission(current: WebProjectEntity, permission: String): WebProjectEntity {
        val perms = current.getPermissionList().toMutableSet()
        if (perms.contains(permission)) {
            perms.remove(permission)
        } else {
            perms.add(permission)
        }
        val updated = current.copy(permissionsCsv = perms.joinToString(","))
        updateProject(updated)
        return updated
    }

    fun buildApk(project: WebProjectEntity) {
        val context = getApplication<Application>()
        viewModelScope.launch {
            _buildState.value = BuildUiState.Building("Initializing compiler...", 0.05f)
            try {
                val result = withContext(Dispatchers.IO) {
                    ApkBuilder.buildApk(
                        context = context,
                        project = project,
                        onProgress = { step, progress ->
                            _buildState.value = BuildUiState.Building(step, progress)
                        }
                    )
                }
                _buildState.value = BuildUiState.Success(result)
            } catch (e: Exception) {
                _buildState.value = BuildUiState.Error(e.message ?: "Build failed")
            }
        }
    }

    fun resetBuildState() {
        _buildState.value = BuildUiState.Idle
    }

    fun exportProjectZip(project: WebProjectEntity) {
        val context = getApplication<Application>()
        viewModelScope.launch {
            _exportState.value = ExportUiState.Exporting
            try {
                val zipFile = withContext(Dispatchers.IO) {
                    AndroidProjectExporter.exportProjectZip(context, project)
                }
                _exportState.value = ExportUiState.Success(zipFile)
            } catch (e: Exception) {
                _exportState.value = ExportUiState.Error(e.message ?: "Export failed")
            }
        }
    }

    fun resetExportState() {
        _exportState.value = ExportUiState.Idle
    }

    fun installApk(context: Context, apkFile: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            _toastMessage.value = "Unable to launch installer: ${e.message}"
        }
    }

    fun shareApk(context: Context, apkFile: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, apkFile.name)
                putExtra(Intent.EXTRA_TEXT, "Here is your Android APK: ${apkFile.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share APK"))
        } catch (e: Exception) {
            _toastMessage.value = "Share failed: ${e.message}"
        }
    }

    fun shareZip(context: Context, zipFile: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                zipFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, zipFile.name)
                putExtra(Intent.EXTRA_TEXT, "Android Studio Source Code: ${zipFile.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Export Android Studio Project"))
        } catch (e: Exception) {
            _toastMessage.value = "Export share failed: ${e.message}"
        }
    }

    fun addConsoleLog(level: String, message: String, line: Int) {
        val item = ConsoleLogItem(level = level, message = message, line = line)
        val list = _consoleLogs.value.toMutableList()
        if (list.size > 200) list.removeAt(0)
        list.add(item)
        _consoleLogs.value = list
    }

    fun clearConsoleLogs() {
        _consoleLogs.value = emptyList()
    }
}
