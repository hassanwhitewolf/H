package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.builder.IconGenerator
import com.example.data.WebProjectEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Web2APK", appName)
    }

    @Test
    fun `web project entity permission checks`() {
        val project = WebProjectEntity(
            id = "test_1",
            name = "Test App",
            packageName = "com.test.app",
            permissionsCsv = "INTERNET,STORAGE,CAMERA"
        )
        assertTrue(project.hasPermission("INTERNET"))
        assertTrue(project.hasPermission("STORAGE"))
        assertTrue(project.hasPermission("CAMERA"))
        assertEquals(false, project.hasPermission("LOCATION"))
    }

    @Test
    fun `icon generator creates valid bitmap`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val bitmap = IconGenerator.generateIconBitmap(context, null, "CYAN_GLOBE", 96)
        assertNotNull(bitmap)
        assertEquals(96, bitmap.width)
        assertEquals(96, bitmap.height)
    }
}
